import json

from flask import Flask
from flask import render_template
from flask_wtf import FlaskForm
from werkzeug.utils import redirect
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired


class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandex_secret_key'

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/')
@app.route('/index')
def index():
    return render_template('base.html', title='заготовка')


@app.route('/odd_even')
def odd_even():
    return render_template('odd_even.html', number=3)


@app.route('/news')
def news():
    with open('news.json', 'rt', encoding='utf-8') as f:
        news_list = json.loads(f.read())
    print(news_list)
    return render_template('news.html', news=news_list)


@app.route('/test')
def test():
    return render_template('test.html', title="тест")


@app.route('/training/<prof>')
def professia(prof):
    if 'инженер' in prof or 'строитель' in prof:
        return render_template('base.html', mesto="Инженерные тренажеры", image="/static/img/img.png")
    else:
        return render_template('base.html', mesto="Научные симуляторы", image="/static/img/img_1.png")





if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
